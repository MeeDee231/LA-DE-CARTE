const axios = require('axios');

axios.get('https://api.spotify.com/v1/search?q=we+cant+be+friends&type=track', {
    headers: {
    'Authorization': 'Bearer BQAgwynxViHOMpd6ZAWe7EdUJxjpjjBV4_Vzzaf-yyKICKzmIDzp-zqJIZeQE-xCTEBnh_qDeVc5B_PEUXf84FYucUJNExpQ9GUyKT9jJHE7AiFVi4OFLjeu3HYiak7gSKl2ZFCwqqH2-9BnS6WXqC7UkOcFpfr9rkZKHeAa5Hzd3yD6ARioYH0UPw0sIWjH-R38vgDozaw3QKM'
}
}).then((data)=>{
    console.log(data.data.tracks.items[0].id);
})