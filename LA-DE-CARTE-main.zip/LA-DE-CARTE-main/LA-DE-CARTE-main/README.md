# LA-DE-CARTE MEMBERS
Rovic Paradiang
Maria Daniella Dianne Pelejotes
Marienel Retutas
